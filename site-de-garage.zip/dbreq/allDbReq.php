<?php

function scheduleReq($pdo)
{
    echo "scheduleReq()";
        $request="SELECT * FROM horaires WHERE jour != :mark1";
        $filter=""; //variable des enregistrements à exclure. là les enregistrements vides
        $stmt = $pdo -> prepare($request);                      // préparation de la requête
        $stmt->bindParam(':mark1', $filter, PDO::PARAM_STR);    // nom marker, val, type
        $stmt->execute();

        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);            // traitement de sortie en tab associatif dans $result
        return $result;
}

function cardsReq ()  //mettre les requetes sql ici
{
    echo "entree sortcard";

    $cars=[
    ['name'=>'bmw bla bla'],
    ['name'=>'bmw drgebla'],
    ['name'=>'dsrg bla'],
    ['name'=>'bmw bdfhbla'],
    ['name'=>'bmw blstrjha'],
    ['name'=>'MERC bla bla']
    ];
    return $cars;
}

function readService ($pdo)
{
    $filter="";                                             //variable des enregistrements à exclure. là les enregistrements vides
    $stmt = $pdo -> prepare("SELECT * FROM services WHERE description != :mark1");                      // préparation de la requête
    $stmt->bindParam(':mark1', $filter, PDO::PARAM_STR);    // nom marker, val, type
    $stmt->execute();

    $result = $stmt->fetchAll(PDO::FETCH_ASSOC);            // traitement de sortie en tab associatif dans $result
    return $result;
}

function readTable ($pdo, $request)
{
    $filter="";                                             //variable des enregistrements à exclure. là les enregistrements vides
    $stmt = $pdo -> prepare($request);                      // préparation de la requête
    $stmt->bindParam(':mark1', $filter, PDO::PARAM_STR);    // nom marker, val, type
    $stmt->execute();

    $result = $stmt->fetchAll(PDO::FETCH_ASSOC);            // traitement de sortie en tab associatif dans $result
    return $result;
}

function deleteService ($pdo, $b)
{
    $stmt = $pdo -> prepare("DELETE FROM `services` WHERE `services`.`description` = '$b'");
    $stmt->execute();
    header('Location: managerAdmin.php');
}

function modifyService ($pdo, $a, $b)
{
    $stmt = $pdo -> prepare("UPDATE `services` SET `description` = '$a' WHERE `services`.`description` = '$b'");
    $stmt->execute();
    header('Location: managerAdmin.php');                    //la bdd est mise à jour alors raffraichir la page
}

function addService($pdo, $a)
{
    $stmt = $pdo -> prepare("INSERT INTO `services` (`id-services`, `description`) VALUES (NULL, '$a')");
    $stmt->execute();
    header('Location: managerAdmin.php');
}

function readSelectedSchedulesToModify ($pdo, $jour)
{
    if ($jour=="xxx")
    {
        return;
    }
    $stmt = $pdo -> prepare("SELECT * FROM horaires WHERE jour = '$jour'");
    $stmt->execute();
    $resultSchedule = $stmt->fetchAll(PDO::FETCH_ASSOC);
    return $resultSchedule;
}

function modifySchedules ($pdo) // recording in db schudele of day selected
{
    if (!(empty($_GET['mod'])))
    {
        $jour=$_GET['jour'];
        $morningStartH=$_GET['morningStartH'];
        $morningStartMn=$_GET['morningStartMn'];
        $morningEndH=$_GET['morningEndH'];
        $morningEndMn=$_GET['morningEndMn'];
        $afternoonStartH=$_GET['afternoonStartH'];
        $afternoonStartMn=$_GET['afternoonStartMn'];
        $afternoonEndH=$_GET['afternoonEndH'];
        $afternoonEndMn=$_GET['afternoonEndMn'];

        $stmt = $pdo -> prepare("UPDATE horaires SET
        morningStartH ='$morningStartH',
        morningStartMn ='$morningStartMn',
        morningEndH ='$morningEndH',
        morningEndMn ='$morningEndMn',
        afternoonStartH ='$afternoonStartH',
        afternoonStartMn ='$afternoonStartMn',
        afternoonEndH ='$afternoonEndH',
        afternoonEndMn ='$afternoonEndMn'
        WHERE jour = '$jour'");

        $stmt->execute();

        header('Location: managerAdmin.php');
    }
}


