<?php

// fonction de connexion à la db
function connectToDb ($mysqlDsn,$userLogin,$userPwd)
{
    try {
        $pdo=null;                                         // supprime la connexion éventuelle en cours
        $pdo = new PDO($mysqlDsn, $userLogin, $userPwd);   // créer une instance de classe PDO
        echo " vous êtes connecté ";
        return $pdo;
    }
    catch (PDOException $e) {                              // capture du flux d'erreur
        echo ' la connexion a échouée ';                         // remplacer le msg d'erreur par le mien
        $pdo=null;                                         // supprime l'instance de classe PDO
        exit;                                              // et fin de script car le site ne peut pas marcher
    }
}

// fonction de déconnexion à la db
function exitDb ($pdo)
{
    $pdo=null;
    echo "vous êtes déconnecté";
}
