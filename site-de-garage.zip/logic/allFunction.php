<?php
require_once $_SERVER['DOCUMENT_ROOT'].'/site-de-garage/display/allDisplayFunction.php';
// ***************************** fonction de lecture des tables de tous les enregistrements services et horaires
// ***************************** la requête est en argument car la fonction est utilisée pour plusieurs tables : services, horaires
function readTable ($pdo, $request) {
    $filter="";                                             //variable des enregistrements à exclure. là les enregistrements vides

    $stmt = $pdo -> prepare($request);                      // préparation de la requête

    $stmt->bindParam(':mark1', $filter, PDO::PARAM_STR);    // nom marker, val, type
    $stmt->execute();
    $result = $stmt->fetchAll(PDO::FETCH_ASSOC);            // traitement de sortie en tab associatif dans $result
    return $result;
}

function deleteService ($pdo, $b) {
    $stmt = $pdo -> prepare("DELETE FROM `services` WHERE `services`.`description` = '$b'");
    $stmt->execute();
    header('Location: managerAdmin.php');
}

function modifyService ($pdo, $a, $b){
    $stmt = $pdo -> prepare("UPDATE `services` SET `description` = '$a' WHERE `services`.`description` = '$b'");
    $stmt->execute();
    header('Location: managerAdmin.php');                    //la bdd est mise à jour alors raffraichir la page
}

function addService($pdo, $a) {
    $stmt = $pdo -> prepare("INSERT INTO `services` (`id-services`, `description`) VALUES (NULL, '$a')");
    $stmt->execute();
    header('Location: managerAdmin.php');
    
}

function readSelectedSchedulesToModify ($pdo, $jour) {
    $stmt = $pdo -> prepare("SELECT * FROM horaires WHERE jour = '$jour'");
    $stmt->execute();
    $result = $stmt->fetchAll(PDO::FETCH_ASSOC);            // traitement de sortie en tab associatif dans $result
    return $result;
}

function modifySchedules ($pdo, $jour, $morningStartH, $morningStartMn, $morningEndH, $morningEndMn,
$afternoonStartH, $afternoonStartMn, $afternoonEndH, $afternoonEndMn){
    $stmt = $pdo -> prepare("UPDATE horaires SET
    morningStartH ='$morningStartH',
    morningStartMn ='$morningStartMn',
    morningEndH ='$morningEndH',
    morningEndMn ='$morningEndMn',
    afternoonStartH ='$afternoonStartH',
    afternoonStartMn ='$afternoonStartMn',
    afternoonEndH ='$afternoonEndH',
    afternoonEndMn ='$afternoonEndMn'
    WHERE jour = '$jour'");
    $stmt->execute();
    }

function sortCards ()  //mettre les requetes sql ici
{
    echo "entree sortcard";

    $cars=[ ['name'=>'bmw bla bla'],
    ['name'=>'bmw drgebla'],
    ['name'=>'dsrg bla'],
    ['name'=>'bmw bdfhbla'],
    ['name'=>'bmw blstrjha'],
    ['name'=>'MERC bla bla']
];
displaySortCards($cars);
}
