<?php
echo $_SERVER['DOCUMENT_ROOT'];
//* page d'admin du patron
require_once $_SERVER['DOCUMENT_ROOT'].'/site-de-garage/constant/allConstant.php';
require_once $_SERVER['DOCUMENT_ROOT'].'/site-de-garage/htmlpiece/pageHeader.php';

require_once $_SERVER['DOCUMENT_ROOT'].'/site-de-garage/controller/controller.php';

controller(4); // display mixed with managing all services
controller(1); // display all schedule days
controller(2); // modify schedule 1 by 1
