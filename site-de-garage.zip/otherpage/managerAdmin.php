<?php
//* page d'admin du patron
require_once $_SERVER['DOCUMENT_ROOT'].'/site-de-garage/constant/allConstant.php';
require_once $_SERVER['DOCUMENT_ROOT'].'/site-de-garage/htmlpiece/pageHeader.php';

//* connexion à la db et traitement des erreurs
require_once $_SERVER['DOCUMENT_ROOT'].'/site-de-garage/constant/allConstant.php';
require_once $_SERVER['DOCUMENT_ROOT'].'/site-de-garage/logic/dbConnexion.php';
$pdo=connectToDb(MYSQLDSN,"root",'');

//* lecture mysql de la table des services
require_once $_SERVER['DOCUMENT_ROOT'].'/site-de-garage/logic/allFunction.php';
$request="SELECT * FROM services WHERE description != :mark1";      // requête à préparer :tout les services différents de "z"
$result=readTable ($pdo, $request);

$j=1;  // cpt pour créer des noms dynamiques afin d'identifier les boutons (pas besoin pr les champs unique par formulaire mais fait quand même)
foreach ($result as $value)    // $value = 1 ligne de $result, changée à chaque passage
{
    //* formulaire pour SUPPRIMER un service : 1 donnée et son bouton supprimer
    ?>
    <form method="get">
        <div>
        <label for="idnom3">description :</label>
        <input type="text" name="aff" id="idnom3" value="<?php echo $value['description'] ?>">
        </div>

        <div>
        <input  type="submit" name="supprimer<?php echo $j ?>" value="supprimer">
        </div>
    </form>
    <?php

    if (!(empty($_GET['supprimer'.$j])))
    {
        $b=$value['description'];
        deleteService ($pdo, $b);
        unset($_GET);
    }
    // formulaire pour MODIFIER un service. j'ai pas include celui des visiteurs car c'est imbriqué
    ?>
    <form method="get">
        <div>
        <label for="idnom1">nouvelle description :</label>
        <input type="text" name="saisie<?php echo $j ?>"  id="idnom1">
        </div>
        
        <div>
        <input  type="submit" name="modifier<?php echo $j ?>" id="idnom1" value="modifier">
        </div>
    </form>
    <?php

    if (!(empty($_GET['saisie'.$j]))&& !(empty($_GET['modifier'.$j])))
    {
        $a=$_GET['saisie'.$j];
        $b=$value['description'];
        modifyService ($pdo, $a, $b);
        unset($_GET);
    }

    $j++;
}
// formulaire pour AJOUTER un service
?>
<form method="get">
    <div>
    <label for="idnom2">description :</label>
    <input type="text" name="add1" id="idnom2">
    </div>

    <div>
    <input  type="submit" name="add2" value="ajouter">
    </div>
</form>
<?php
// si un service est à AJOUTER, alors l'ajouter dans la table services
if (!(empty($_GET['add1']))&& !(empty($_GET['add2'])))
{
    $a=$_GET['add1'];
    addService($pdo, $a);
    unset($_GET);
}

/****** modification du schedule par le user: *******/

/* DEBUT : aff tous les horaires actuels */
require_once $_SERVER['DOCUMENT_ROOT'].'/site-de-garage/htmlpiece/visitorSchedule.php';

/* demander de choisir le jour dont on veut changer des horaires : */
?>
<form method="get">
    <select name="jour" id="jour">
        <option value="lun">lun</option>
        <option value="mar">mar</option>
        <option value="mer">mer</option>
        <option value="jeu">jeu</option>
        <option value="ven">ven</option>
        <option value="sam">sam</option>
        <option value="dim">dim</option>
    </select>
    <div>
    <input  type="submit" name="choixButton" value="choisir">
    </div>
</form>

<?php
/* rechercher dans la base l'enregistrement à modifier */
//$jour="lun"; // forcer un jour pour que le programme fonctionne
if (!(empty($_GET['choixButton']))) //on récupère $get que si le user à cliqué modifier. sinon $get est vide
    {
        $jour=$_GET['jour'];
        $result=readSelectedSchedulesToModify ($pdo, $jour);
    }
        
    
        
/* préparation du formulaire de modification du schedule */
 // tableau des tranches horaires possible. nom des select et pour faire les attributs selected
$title=['morningStartH','morningStartMn','morningEndH','morningEndMn','afternoonStartH','afternoonStartMn','afternoonEndH','afternoonEndMn'];
$hours=[]; // tableau des heures possible des <select>
$minutes=[]; // tableau des minutes possible des <select>

 /* remplir les tableaux heures et minutes */
for ($i=0 ; $i<=23 ; $i++) {
    $hours[$i]=$i;
}
//var_dump($hours);
for ($i=0 ; $i<=59 ; $i++)
{
    $minutes[$i]=$i;
}
//var_dump($minutes);
/* faire les select du formulaire de l'enregistrement à modifier */
?> <form method="get"> <?php
for ($i=0 ; $i<=6 ; $i=$i+2) // on fait 2 select à chaque fois : heures et puis minutes
{
    ?>
    <form method="get">
        <!-- le select des heures -->
        <?php echo $title[$i]; ?>
        <select name="<?php echo $title[$i]; ?>"id="<?php echo $title[$i];?>">
            
            <?php
            
            for ($j =0 ; $j<=23 ; $j++)
            {
                ?>
                <option value="<?php echo $hours[$j];?>"
                <?php if($hours[$j]==$result[0][$title[$i]]){echo " selected";} ?>><?php echo $hours[$j]; ?></option>
                <!-- on retrouve le selected dans le tableau $value  -->
            <?php
            }
            ?>
        </select>
        <!-- le select des minutes -->
        <?php echo $title[$i+1]; ?>
        <select name="<?php echo $title[$i+1];?>"id="<?php echo $title[$i+1];?>">
            <?php
            for ($j =0 ; $j<=59 ; $j++)
            {
                ?>
                <option value="<?php echo $minutes[$j];?>"
                <?php if($minutes[$j]==$result[0][$title[$i+1]]) echo " selected"; ?>><?php echo $minutes[$j]; ?></option>
            <?php
            }
            ?>
        </select>
<?php
}

?>
        <div>
            <input  type="submit" name="mod" value="modifier">
        </div>
    </form>

<?php

if (!(empty($_GET['mod']))) //on récupère $get que si le user à cliqué modifier. sinon $get est vide
{
    $jour=$value['jour'];
    $morningStartH=$_GET['morningStartH'];
    $morningStartMn=$_GET['morningStartMn'];
    $morningEndH=$_GET['morningEndH'];
    $morningEndMn=$_GET['morningEndMn'];
    $afternoonStartH=$_GET['afternoonStartH'];
    $afternoonStartMn=$_GET['afternoonStartMn'];
    $afternoonEndH=$_GET['afternoonEndH'];
    $afternoonEndMn=$_GET['afternoonEndMn'];

    modifySchedules ($pdo, $jour, $morningStartH, $morningStartMn, $morningEndH, $morningEndMn, $afternoonStartH, $afternoonStartMn, $afternoonEndH , $afternoonEndMn, $afternoonEndMn);
}


exitDb ($pdo);
require_once $_SERVER['DOCUMENT_ROOT'].'/site-de-garage/htmlpiece/pageFooter.php';
