<!-- formulaire de connexion  -->
<?php
require_once $_SERVER['DOCUMENT_ROOT'].'/site-de-garage/constant/allConstant.php';
require_once $_SERVER['DOCUMENT_ROOT'].'/site-de-garage/htmlpiece/pageHeader.php';
?>
<div>
    <?php
    echo "formulaire de connexion";
    ?>
</div>
<div>
    <label for="email">tapez votre email de connexion :</label>
    <br>
    <input type="email" name="email" id="email">
</div>
<br>
<div>
    <label for="password">tapez votre mot de passe :</label>
    <br>
    <input type="password" name="password" id="password">
</div>
<p>
    <a href="managerAdmin.php">
    lien vers admin du patron
    </a>
</p>

<?php require_once $_SERVER['DOCUMENT_ROOT'].'/site-de-garage/htmlpiece/pageFooter.php';
