<!-- page d'admin des voitures -->
<?php
require_once $_SERVER['DOCUMENT_ROOT'].'/site-de-garage/constants/allConstants.php';
require_once $_SERVER['DOCUMENT_ROOT']."/site-de-garage/htmlPieces/pagesHeader.html";


require_once $_SERVER['DOCUMENT_ROOT'].'/site-de-garage/htmlpieces/pagesFooter.php';
