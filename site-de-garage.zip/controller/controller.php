<!-- fichier du controller pour l'exemple MVC -->
<!-- 0 : code pour trie et affichage des cartes des voitures -->
<?php
require_once $_SERVER['DOCUMENT_ROOT'].'/site-de-garage/logic/allFunction.php';

function controller(int $controllerNumber)
{
echo "entree dans le controller";
    if ($controllerNumber == 0)
    {
        sortCards();
    }
}
