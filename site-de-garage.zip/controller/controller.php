<?php

// fichier du controller :
// 0 : sort and display cars's cards
// 3 : read and display services
// 1 : read and display schedule
// 2 : managing schedule
// 4 : managing services

function controller(int $controllerNumber)
{
    if ($controllerNumber == "0")
    {
        require_once $_SERVER['DOCUMENT_ROOT'].'/site-de-garage/display/allDisplayFunction.php'; // form to ask to user choice of price
        $arrayPrice=formSortCar();

        require_once $_SERVER['DOCUMENT_ROOT'].'/site-de-garage/dbreq/dbConnexion.php'; // open line to db
        $pdo=connectToDb(MYSQLDSN,"root",'');

        require_once $_SERVER['DOCUMENT_ROOT'].'/site-de-garage/dbreq/allDbReq.php'; //prepare req and read cars selected
        $arrayCar=sortCarReq($arrayPrice);

        require_once $_SERVER['DOCUMENT_ROOT'].'/site-de-garage/display/allDisplayFunction.php'; //display array of cars into cards
        displayCar($arrayCar);

        require_once $_SERVER['DOCUMENT_ROOT'].'/site-de-garage/dbreq/dbConnexion.php'; //close line to db
        exitDb($pdo);
    }

    if ($controllerNumber == "3")
    {
        require_once $_SERVER['DOCUMENT_ROOT'].'/site-de-garage/dbreq/dbConnexion.php'; // open line to db
        $pdo=connectToDb(MYSQLDSN,"root",'');

        require_once $_SERVER['DOCUMENT_ROOT'].'/site-de-garage/dbreq/allDbReq.php'; //prepare req and read all services
        $result=readService ($pdo);

        require_once $_SERVER['DOCUMENT_ROOT'].'/site-de-garage/display/allDisplayFunction.php'; //display all services
        displayService($result);

        require_once $_SERVER['DOCUMENT_ROOT'].'/site-de-garage/dbreq/dbConnexion.php'; //close line to db
        exitDb($pdo);
    }

    if ($controllerNumber == "4") // 4 : managing services
    {
        require_once $_SERVER['DOCUMENT_ROOT'].'/site-de-garage/dbreq/dbConnexion.php'; // open line to db
        $pdo=connectToDb(MYSQLDSN,"root",'');

        require_once $_SERVER['DOCUMENT_ROOT'].'/site-de-garage/dbreq/allDbReq.php'; //prepare req and read all services
        $result=readService ($pdo);

        require_once $_SERVER['DOCUMENT_ROOT'].'/site-de-garage/display/allDisplayFunction.php'; //display, add, del and modify services
        manageService($result, $pdo);

        require_once $_SERVER['DOCUMENT_ROOT'].'/site-de-garage/dbreq/dbConnexion.php'; //close line to db
        exitDb($pdo);
    }

    if ($controllerNumber == "1") // 1 : read and display schedule
    {
        require_once $_SERVER['DOCUMENT_ROOT'].'/site-de-garage/dbreq/dbConnexion.php'; //open line to db
        $pdo=connectToDb(MYSQLDSN,"root",'');

        require_once $_SERVER['DOCUMENT_ROOT'].'/site-de-garage/dbreq/allDbReq.php'; //prepare req and read db
        $result=scheduleReq($pdo);

        require_once $_SERVER['DOCUMENT_ROOT'].'/site-de-garage/display/allDisplayFunction.php'; //display all schedule
        displaySchedule($result);

        require_once $_SERVER['DOCUMENT_ROOT'].'/site-de-garage/dbreq/dbConnexion.php'; //close line to db
        exitDb($pdo);
    }

    if ($controllerNumber == "2") // 2 : managing schedule
    {

        require_once $_SERVER['DOCUMENT_ROOT'].'/site-de-garage/display/allDisplayFunction.php'; // user select a day to change schedule
        $jour=daySelect();

        $pdo=connectToDb(MYSQLDSN,"root",'');  //open line to db
        
        $resultSchedule=readSelectedSchedulesToModify ($pdo, $jour); // prepare req and read day to change into db

        displayScheduleToModify ($resultSchedule, $jour); // display and user changes data of the day selected before

        modifySchedules ($pdo); // the new schedule of the days selected is change into db

        require_once $_SERVER['DOCUMENT_ROOT'].'/site-de-garage/dbreq/dbConnexion.php'; //close line to db
        exitDb($pdo);
    }
}
