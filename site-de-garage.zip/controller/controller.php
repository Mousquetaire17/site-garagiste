<?php

// fichier du controller
// 0 : sort and display cars's cards
// 3 : read and display services
// 1 : read and display schedule
// 2 : 
function controller(int $controllerNumber)
{
    if ($controllerNumber == "0")
    {
        require_once $_SERVER['DOCUMENT_ROOT'].'/site-de-garage/dbreq/allDbReq.php'; //prepare and request
        $cars=cardsReq();
        require_once $_SERVER['DOCUMENT_ROOT'].'/site-de-garage/display/allDisplayFunction.php'; //display cards
        displayCards($cars);
    }

    if ($controllerNumber == "3")
    {
        require_once $_SERVER['DOCUMENT_ROOT'].'/site-de-garage/dbreq/dbConnexion.php'; // open line to db
        $pdo=connectToDb(MYSQLDSN,"root",'');

        require_once $_SERVER['DOCUMENT_ROOT'].'/site-de-garage/dbreq/allDbReq.php'; //prepare and request
        $result=readService ($pdo);

        require_once $_SERVER['DOCUMENT_ROOT'].'/site-de-garage/display/allDisplayFunction.php'; //display services
        displayService($result);

        require_once $_SERVER['DOCUMENT_ROOT'].'/site-de-garage/dbreq/dbConnexion.php'; //close line to db
        exitDb($pdo);
    }

    if ($controllerNumber == "1") // control number == 1 for index.php schuddle display
    {
        require_once $_SERVER['DOCUMENT_ROOT'].'/site-de-garage/dbreq/dbConnexion.php'; //connexion
        $pdo=connectToDb(MYSQLDSN,"root",'');

        require_once $_SERVER['DOCUMENT_ROOT'].'/site-de-garage/dbreq/allDbReq.php'; //préparation et requête
        $result=scheduleReq($pdo);

        require_once $_SERVER['DOCUMENT_ROOT'].'/site-de-garage/display/allDisplayFunction.php'; //affichage des données
        displaySchedule($result);

        require_once $_SERVER['DOCUMENT_ROOT'].'/site-de-garage/dbreq/dbConnexion.php'; //fin de la connexion
        exitDb($pdo);
    }

    if ($controllerNumber == "2") // control number == 2 for managerAdmin.php
    {
        require_once $_SERVER['DOCUMENT_ROOT'].'/site-de-garage/display/allDisplayFunction.php';
        $jour=daySelect(); // appel form de sélection du jour à modifier

        $pdo=connectToDb(MYSQLDSN,"root",'');
        
        $resultSchedule=readSelectedSchedulesToModify ($pdo, $jour);

        displayScheduleToModify ($resultSchedule, $jour);

        modifySchedules ($pdo);

        require_once $_SERVER['DOCUMENT_ROOT'].'/site-de-garage/dbreq/dbConnexion.php'; //fin de la connexion
        exitDb($pdo);
    }
}
