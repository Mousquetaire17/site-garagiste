<?php
// path of files used
require_once $_SERVER['DOCUMENT_ROOT'].'/site-de-garage/constant/allConstant.php';
require_once $_SERVER['DOCUMENT_ROOT'].'/site-de-garage/controller/controller.php';
// header -->
require_once $_SERVER['DOCUMENT_ROOT'].'/site-de-garage/htmlpiece/pageHeader.php';
?>
<!-- link to manager and staff connection page -->
<div>
    <a href="otherpage/userConnexion.php">vers la page de connexion</a>
</div>

<!-- services -->
<?php
$controllerNumber = "3";
controller($controllerNumber);

// cars
$controllerNumber = "0";
controller($controllerNumber);

// contact
require_once $_SERVER["DOCUMENT_ROOT"].'/site-de-garage/htmlpiece/visitorContact.php';

// schedule
$controllerNumber = "1";
controller($controllerNumber);

// footer
require_once $_SERVER['DOCUMENT_ROOT'].'/site-de-garage/htmlpiece/pageFooter.php';

// end of script
exit;
