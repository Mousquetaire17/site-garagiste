<?php

// path of files used
require_once $_SERVER['DOCUMENT_ROOT'].'/site-de-garage/constant/allConstant.php';
require_once $_SERVER['DOCUMENT_ROOT'].'/site-de-garage/controller/controller.php';

//entête de page -->
require_once $_SERVER['DOCUMENT_ROOT'].'/site-de-garage/htmlpiece/pageHeader.php';

?>

<!-- link to manager and staff connection page -->
<div>
    <a href="otherpage/userConnexion.php">vers la page de connexion</a>
</div>

<h1>Services de réparation</h1>

<?php

// lecture et affichage des services -->
$controllerNumber = "3";
controller($controllerNumber);

// lecture et affichage des voitures à vendre -->
$controllerNumber = "0";
controller($controllerNumber);

// lecture et affichage des coordonnées -->
require_once $_SERVER["DOCUMENT_ROOT"].'/site-de-garage/htmlpiece/visitorContact.php';

// lecture et affichage des horaires d'ouverture -->
$controllerNumber = "1";
controller($controllerNumber);

// pied de page -->
require_once $_SERVER['DOCUMENT_ROOT'].'/site-de-garage/htmlpiece/pageFooter.php';

//arrêt du script
exit;
