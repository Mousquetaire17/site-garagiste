<?php
// fichiers necessaires
require_once $_SERVER['DOCUMENT_ROOT'].'/site-de-garage/constant/allConstant.php';
require_once $_SERVER['DOCUMENT_ROOT'].'/site-de-garage/htmlpiece/pageHeader.php';
require_once $_SERVER['DOCUMENT_ROOT'].'/site-de-garage/controller/controller.php';
?>

<!-- lien de connexion pour le personnel et le patron  -->
<div>
    <a href="otherpage/userConnexion.php">vers la page de connexion</a>
</div>

<!-- lecture et affichage des services -->
<h1>Services de réparation</h1>
<?php
require_once $_SERVER['DOCUMENT_ROOT'].'/site-de-garage/htmlpiece/visitorService.php';

// lecture et affichage des voitures à vendre en MVC-->
$controllerNumber = "0";
controller($controllerNumber);

// lecture et affichage des coordonnées -->
require_once $_SERVER['DOCUMENT_ROOT'].'/site-de-garage/htmlpiece/visitorContact.php';

// lecture et affichage des horaires d'ouverture -->
require_once $_SERVER['DOCUMENT_ROOT'].'/site-de-garage/htmlpiece/visitorSchedule.php';

//  pied de page html de la page -->
require_once $_SERVER['DOCUMENT_ROOT'].'/site-de-garage/htmlpiece/pageFooter.php';

exit; //arrêt du script
