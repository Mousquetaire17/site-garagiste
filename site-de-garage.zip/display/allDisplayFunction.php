<?php

// futur page pour tout MVC

function displayService($result)
{
foreach ($result as $value)
{
?>
    <form method="get">
        <div>
            <label for="idnom3"></label>
            <input type="text" name="aff" id="idnom3" value="<?php echo $value['description']; ?>">
        </div>
    </form>
<?php
}
function displayCards($cars)
{
?>
<div>
    <p> Liste de nos voitures d'ocassion </p>
</div>

<!-- container classique bootstrap  -->
<div class="container">
    <!-- grills bootstrap  -->
    <div class="row row row-cols-1 row-cols-md-2 g-4">
        
        <?php
        foreach($cars as $info => $carIndex) { // ou sans key foreach($cars as $carIndex) {
        ?>
            <div class="col">
                <div class="card" style="width: 18rem;">
                    <!-- <img class="card-img-top" src="..." alt="Card image cap"> -->
                        <div class="card-body">
                            <h5 class="nom"><?php echo $info; echo $carIndex['name']; ?></h5>
                            <p class="card-text">Some quick  to build on the card title and make up the bulk of the card's content.</p>
                        </div>
                        <ul class="list-group list-group-flush">
                        <li class="list-group-item">Cras justo odio</li>
                        <li class="list-group-item">Dapibus ac facilisis in</li>
                        <li class="list-group-item">Vestibulum at eros</li>
                        </ul>
                            <div class="card-body">
                                <a href="#" class="btn btn-primary">Go somewhere</a>
                            </div>
                </div>
            </div>
        <?php
        }
        ?>

    </div>
</div>
<?php
}
}

function displaySchedule($result)
{
    echo "displaySchedule()";


// traitement des données venant de la db
foreach ($result as $value) {

?>
    <form method="get">

    <div>
    <input type="text" name="nom" id="idnom3" value="<?php echo $value['jour'], "    "
    ,$value['morningStartH'], ":",$value['morningStartMn'], " - ",$value['morningEndH'],":",$value['morningEndMn'], ", ",
    $value['afternoonStartH'], ":",$value['afternoonStartMn'], " - ",$value['afternoonEndH'],":",$value['afternoonEndMn'];
    ?>">
    </div>
    
    </form>

    <?php

}
// déconnexion de la db
return;
}

function daySelect()
{
    echo " E dayselect() ";
    ?>
    <form method="get">
        <select name="jour" id="jour">
            <option value="lun">lun</option>
            <option value="mar">mar</option>
            <option value="mer">mer</option>
            <option value="jeu">jeu</option>
            <option value="ven">ven</option>
            <option value="sam">sam</option>
            <option value="dim">dim</option>
        </select>
        <div>
        <input  type="submit" name="choixButton" value="choisir">
        </div>
    </form>

    <?php
    $jour="xxx";
    if (!(empty($_GET['choixButton'])))
        {
            $jour=$_GET['jour'];
            echo " jour sélectionné : ", $jour, "  ";
            echo " S dayselect() ";
            return $jour;
        }
        echo " jour non sélectionné : ", $jour, "  ";
        echo " S dayselect() ";
    return $jour;
}

function displayScheduleToModify($resultSchedule, $jour)
{
if (!(empty($resultSchedule)))
{    /* préparation du formulaire de modification du schedule */
    // tableau des tranches horaires possible. nom des select et pour faire les attributs selected
    $title=['morningStartH','morningStartMn','morningEndH','morningEndMn','afternoonStartH','afternoonStartMn','afternoonEndH','afternoonEndMn'];
    $hours=[]; // tableau des heures possible des <select>
    $minutes=[]; // tableau des minutes possible des <select>

    /* remplir les tableaux heures et minutes */
    for ($i=0 ; $i<=23 ; $i++) {
        $hours[$i]=$i;
    }
    //var_dump($hours);
    for ($i=0 ; $i<=59 ; $i++)
    {
        $minutes[$i]=$i;
    }
    //var_dump($minutes);
    /* faire les select du formulaire de l'enregistrement à modifier */
    ?> <form method="get"> <?php
    for ($i=0 ; $i<=6 ; $i=$i+2) // on fait 2 select à chaque fois : heures et puis minutes
    {
        ?>
        <form method="get">
        <!-- le select des heures -->
            <?php echo $title[$i]; ?>
            <select name="<?php echo $title[$i]; ?>"id="<?php echo $title[$i];?>">
            
            <?php
            
            for ($j =0 ; $j<=23 ; $j++)
            {
                ?>
                <option value="<?php echo $hours[$j];?>"
                <?php if($hours[$j]==$resultSchedule[0][$title[$i]]){echo " selected";} ?>><?php echo $hours[$j]; ?></option>
                <!-- on retrouve le selected dans le tableau $value  -->
            <?php
            }
            ?>
        </select>
        <!-- le select des minutes -->
        <?php echo $title[$i+1]; ?>
        <select name="<?php echo $title[$i+1];?>"id="<?php echo $title[$i+1];?>">
            <?php
            for ($j =0 ; $j<=59 ; $j++)
            {
                ?>
                <option value="<?php echo $minutes[$j];?>"
                <?php if($minutes[$j]==$resultSchedule[0][$title[$i+1]]) echo " selected"; ?>><?php echo $minutes[$j]; ?></option>
            <?php
            }
            ?>
        </select>
    <?php
    }

    ?>
    <div>
            <label for="jour"></label>
            <input type="text" name="jour" id="jour" value="<?php echo $jour; ?>">
        </div>
        <div>
            <input  type="submit" name="mod" value="modifier">
        </div>
    </form>

<?php

}

}
