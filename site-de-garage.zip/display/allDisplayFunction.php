<!-- futur page pour tout MVC  -->
<?php
require_once $_SERVER['DOCUMENT_ROOT'].'/site-de-garage/logic/allFunction.php';



function displaySortCards ($cars)
{
?>
<div>
    <p> Liste de nos voitures d'ocassion </p>
</div>

<!-- container classique bootstrap  -->
<div class="container">
    <!-- grills bootstrap  -->
    <div class="row row row-cols-1 row-cols-md-2 g-4">
        
        <?php
        foreach($cars as $info => $carIndex) { // ou sans key foreach($cars as $carIndex) {
        ?>
            <div class="col">
                <div class="card" style="width: 18rem;">
                    <!-- <img class="card-img-top" src="..." alt="Card image cap"> -->
                        <div class="card-body">
                            <h5 class="nom"><?php echo $info; echo $carIndex['name']; ?></h5>
                            <p class="card-text">Some quick  to build on the card title and make up the bulk of the card's content.</p>
                        </div>
                        <ul class="list-group list-group-flush">
                        <li class="list-group-item">Cras justo odio</li>
                        <li class="list-group-item">Dapibus ac facilisis in</li>
                        <li class="list-group-item">Vestibulum at eros</li>
                        </ul>
                            <div class="card-body">
                                <a href="#" class="btn btn-primary">Go somewhere</a>
                            </div>
                </div>
            </div>
        <?php
        }
        ?>

    </div>
</div>
<?php
}
