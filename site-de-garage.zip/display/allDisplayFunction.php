<?php
function displayService($result)
{
?>
<div>
    <h1>Services de réparation</h1>
</div>
<?php
    foreach ($result as $value)
    {
    ?>
        <form method="get">
            <div>
                <label for="idnom3"></label>
                <input type="text" name="aff" id="idnom3" value="<?php echo $value['description']; ?>">
            </div>
        </form>
    <?php
    }
}
function formSortCar()
{
    $priceLow=0;
    $priceHow=0;
    ?>

    <div>
        <input type="range" id="range" min="<?php $priceLow ?>" max="<?php $priceHow ?>">
    </div>
    <?php
    $priceLow=1;
    $priceHigh=1;
    $arrayPrice=[[$priceLow] [$priceHigh]];
    return $arrayPrice;
}

function displayCar($arrayCar)
{
    echo $arrayCar;
}
function displayCards($cars)
{
?>
    <div>
        <h1> Liste de nos voitures d'ocassion </h1>
    </div>
    <!-- container classique bootstrap  -->
    <div class="container">
        <!-- grills bootstrap  -->
        <div class="row row row-cols-1 row-cols-md-2 g-4">
            <?php
            foreach($cars as $info => $carIndex)
            { // ou sans key foreach($cars as $carIndex) {
            ?>
                <div class="col">
                    <div class="card" style="width: 18rem;">
                        <!-- <img class="card-img-top" src="..." alt="Card image cap"> -->
                        <div class="card-body">
                            <h5 class="nom"><?php echo $info; echo $carIndex['name']; ?></h5>
                            <p class="card-text">Some quick  to build on the card title and make up the bulk of the card's content.</p>
                        </div>
                        <ul class="list-group list-group-flush">
                            <li class="list-group-item">Cras justo odio</li>
                            <li class="list-group-item">Dapibus ac facilisis in</li>
                            <li class="list-group-item">Vestibulum at eros</li>
                        </ul>
                            <div class="card-body">
                                <a href="#" class="btn btn-primary">Go somewhere</a>
                            </div>
                    </div>
                </div>
            <?php
            }
            ?>
        </div>
    </div>
<?php
}

function displaySchedule($result)
{
    foreach ($result as $value)
    {
    ?>
        <form method="get">
            <div>
            <input type="text" name="nom" id="idnom3" value="<?php echo $value['jour'], "    "
            ,$value['morningStartH'], ":",$value['morningStartMn'], " - ",$value['morningEndH'],":",$value['morningEndMn'], ", ",
            $value['afternoonStartH'], ":",$value['afternoonStartMn'], " - ",$value['afternoonEndH'],":",$value['afternoonEndMn'];
            ?>">
            </div>
        </form>
    <?php
    }
}

function daySelect()
{
?>
    <form method="get">
        <select name="jour" id="jour">
            <option value="lun">lun</option>
            <option value="mar">mar</option>
            <option value="mer">mer</option>
            <option value="jeu">jeu</option>
            <option value="ven">ven</option>
            <option value="sam">sam</option>
            <option value="dim">dim</option>
        </select>
        <div>
        <input  type="submit" name="choixButton" value="choisir">
        </div>
    </form>
    <?php
    $jour="xxx";
    if (!(empty($_GET['choixButton'])))
    {
        $jour=$_GET['jour'];
        echo " jour sélectionné : ", $jour, "  ";
        echo " S dayselect() ";
        return $jour;
    }
        echo " jour non sélectionné : ", $jour, "  ";
        echo " S dayselect() ";
    return $jour;
}

function displayScheduleToModify($resultSchedule, $jour)
{
    if (!(empty($resultSchedule)))
    {
        //arrays of titles (same name row in db), hours and minutes
        $title=['morningStartH','morningStartMn','morningEndH','morningEndMn','afternoonStartH','afternoonStartMn','afternoonEndH','afternoonEndMn'];
        $hours=[];
        $minutes=[];
        // making arrays hours and minutes
        for ($i=0 ; $i<=23 ; $i++)
        {
            $hours[$i]=$i;
        }
        for ($i=0 ; $i<=59 ; $i++)
        {
            $minutes[$i]=$i;
        }
        // making select forms (hours, minutes) (hours, minutes) (hours, minutes) (hours, minutes)
        ?>
        <?php
        for ($i=0 ; $i<=6 ; $i=$i+2)
        {
        ?>
            <form method="get">
                <!-- selevt of hours -->
                <?php echo $title[$i]; ?>
                <select name="<?php echo $title[$i]; ?>"id="<?php echo $title[$i];?>">
                    <?php
                    for ($j =0 ; $j<=23 ; $j++)
                    {
                    ?>
                        <option value="<?php echo $hours[$j];?>"<?php if($hours[$j]==$resultSchedule[0][$title[$i]]){echo " selected";} ?>><?php echo $hours[$j]; ?>
                        </option>
                    <?php
                    }
                    ?>
                </select>
                <!-- select of minutes -->
                <?php echo $title[$i+1]; ?>
                <select name="<?php echo $title[$i+1];?>"id="<?php echo $title[$i+1];?>">
                    <?php
                    for ($j =0 ; $j<=59 ; $j++)
                    {
                        ?>
                        <option value="<?php echo $minutes[$j];?>"<?php if($minutes[$j]==$resultSchedule[0][$title[$i+1]]) {echo " selected";} ?>><?php echo $minutes[$j]; ?>
                        </option>
                    <?php
                    }
                    ?>
                </select>
                <?php
                }
                ?>
                <!-- display day choosen in GET for after as parameter -->
                <div>
                    <label for="jour"></label>
                    <input type="text" name="jour" id="jour" value="<?php echo $jour; ?>">
                </div>
                <!-- action call  -->
                <div>
                    <input  type="submit" name="mod" value="modifier">
                </div>
            </form>
    <?php
    }
}
function manageService($result, $pdo)
{
    $j=1; //generating name. not useful here but used
    foreach ($result as $value)    // services 1 by 1
    {
        ?>
        <!-- form to DISPLAY and DELETE 1 service -->
        <form method="get">
            <div>
                <label for="idnom3">description :</label>
                <input type="text" name="aff" id="idnom3" value="<?php echo $value['description'] ?>">
            </div>
            <!-- button to DELETE 1 service -->
            <div>
                <input  type="submit" name="supprimer<?php echo $j ?>" value="supprimer">
            </div>
        </form>
        <!-- test pour supprimer le service à mettre dans une autre fonction -->
        <?php
        if (!(empty($_GET['supprimer'.$j])))
        {
            $description = $value['description'];
            deleteService ($pdo, $description);
        }
        ?>
        <!-- form to  MODIFY 1 service -->
        <form method="get">
            <div>
            <label for="idnom1">nouvelle description :</label>
            <!-- saisie de la modification du service -->
            <input type="text" name="saisie<?php echo $j ?>"  id="idnom1">
            </div>
            <!-- bouton pour modifier le service  -->
            <div>
            <input  type="submit" name="modifier<?php echo $j ?>" id="idnom1" value="modifier">
            </div>
        </form>
        <!-- test pour supprimer le service à mettre dans une autre fonction -->
        <?php
        if (!(empty($_GET['saisie'.$j]))&& !(empty($_GET['modifier'.$j])))
        {
            $a=$_GET['saisie'.$j];
            $b=$value['description'];
            modifyService ($pdo, $a, $b);
        }
    $j++;
    }
    ?>
    <!-- form to ADD 1 service -->
    <form method="get">
        <div>
        <label for="idnom2">description :</label>
            <input type="text" name="add1" id="idnom2">
        </div>
        <div>
            <input  type="submit" name="add2" value="ajouter">
        </div>
    </form>
    <!-- test pour supprimer le service à mettre dans une autre fonction -->
    <?php
    if (!(empty($_GET['add1']))&& !(empty($_GET['add2'])))
    {
        $a=$_GET['add1'];
        addService($pdo, $a);
    }
}
