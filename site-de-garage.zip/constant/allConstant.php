<?php

// <!-- les constantes du programme  -->
//titre de l'onglet
define('TITLEPAGE','Garage V Parrot');
// caractéristiques de la db
define('MYSQLDSN', 'mysql:host=localhost;dbname=garage;charset=utf8mb4');
define('HOME', '$_SERVER["DOCUMENT_ROOT"]');
