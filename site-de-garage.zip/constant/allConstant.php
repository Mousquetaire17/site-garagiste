<!-- les constantes du programme  -->
<?php
//titre de l'onglet
define('TITLEPAGE','Garage V Parrot');
// caractéristiques de la db
define('MYSQLDSN', 'mysql:host=localhost;dbname=garage;charset=utf8mb4');
