<!-- module des horaires d'ouverture  -->
<div>horraire</div>
<?php

// connexion à la bdd et traitement des erreurs
require_once $_SERVER['DOCUMENT_ROOT'].'/site-de-garage/logic/dbConnexion.php';
$pdo=connectToDb(MYSQLDSN,"root",'');


require_once $_SERVER['DOCUMENT_ROOT'].'/site-de-garage/logic/allFunction.php';
$request="SELECT * FROM horaires WHERE jour != :mark1";
$result=readTable ($pdo, $request);

// traitement des données venant de la db
foreach ($result as $value) {

?>
    <form method="get">

    <div>
    <input type="text" name="nom" id="idnom3" value="<?php echo $value['jour'], "    "
    ,$value['morningStartH'], ":",$value['morningStartMn'], " - ",$value['morningEndH'],":",$value['morningEndMn'], ", ",
    $value['afternoonStartH'], ":",$value['afternoonStartMn'], " - ",$value['afternoonEndH'],":",$value['afternoonEndMn'];
    ?>">
    </div>
    
    </form>

    <?php
   // $j++;
}
// déconnexion de la db
require_once $_SERVER['DOCUMENT_ROOT'].'/site-de-garage/logic/dbConnexion.php';
exitDb($pdo);
