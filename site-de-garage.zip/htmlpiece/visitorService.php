<!-- module d'affichages des services  -->
<?php

// connexion à la bdd et traitement des erreurs
require_once $_SERVER['DOCUMENT_ROOT'].'/site-de-garage/logic/dbConnexion.php';
$pdo=connectToDb(MYSQLDSN,"root",'');


// lecture de la table mysql des services
require_once $_SERVER['DOCUMENT_ROOT'].'/site-de-garage/logic/allFunction.php';// fichier des fonctions de logique requis pour readServicesDb()
$request="SELECT * FROM services WHERE description != :mark1";  // requête à préparer : tout les services différents de "z"
$result=readTable ($pdo, $request);                             // exécution de la req et retour des résultats dans $result


// affichage des services
foreach ($result as $value)
{
?>
    <form method="get">
        <div>
            <label for="idnom3"></label>
            <input type="text" name="aff" id="idnom3" value="<?php echo $value['description']; ?>">
        </div>
    </form>
<?php
}

// fin de connexion
require_once $_SERVER['DOCUMENT_ROOT'].'/site-de-garage/logic/dbConnexion.php';
exitDb($pdo);
