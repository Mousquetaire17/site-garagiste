<!-- module d'affichages des services  -->
<?php




// lecture de la table mysql des services
//require_once $_SERVER['DOCUMENT_ROOT'].'/site-de-garage/logic/allFunction.php';// fichier des fonctions de logique requis pour readServicesDb()
//$request="SELECT * FROM services WHERE description != :mark1";  // requête à préparer : tout les services différents de "z"
                             // exécution de la req et retour des résultats dans $result


// affichage des services


// fin de connexion
//require_once $_SERVER['DOCUMENT_ROOT'].'/site-de-garage/logic/dbConnexion.php';
