<!-- inutilisé : création de classe en cours  -->
<?php
class Cars
{
//propriétés de la classe
    public $name;
    public $km;
    public $yearstart;
    public $price;
    //formulaire de création nom, km, année, prix
    public function __contruct($name, $km, $yearstart, $price):self
    {
        //
    }
    //supprime une voiture dans les tables cards, features, optioncar, photos
    public function deleteCard()
    {
        // select sql de tous les noms des voitures dans un tableau
        // mettre tous les noms du tableau dans une liste box
        // et ajouter un bouton "supprimer"
        // récuperer le nom du select à supprimer dans le get de supprimer dans un tableau
        // prendre le nom dans le tableau du get pour req delete du nom dans les différentes tables
        echo"";
    }

    public function modifyCard()
    {
        echo"";
    }

    public function sortCards()
    {
        echo"";
    }
    
    public function displayCards()
    {
        // select des datas dans un tableau
        // foreach faire une carte
        echo"";
    }

    public function displayDetailsFeaturesPhotos()
    {
        // clic met name de la carte dans get + mot clé display et appel controlleur
        // le controlleur lit le mot clé ce qui déclenche l'appelle de la fonction ici avec le nom et le mot clé
        // la fonction ouvre la db avec le nom et met tout dans un tableau et appelle une fonction d'affichage
        // la fonction d'affichage prend le tableau et alimente un formulaire
        echo"";
    }
}